<?php include ("head.php"); ?>

    <section id="newsletter">
      <div class="container">
        <h1>Subscribe To Our Newsletter</h1>
        <form><ul>
            <li>--                </li>
        </ul>
          <input type="email" placeholder="Enter Email..." required>
          <button type="submit" class="button_1">Subscribe</button>
        </form>
      </div>
    </section>

    <section id="main">
      <div class="container">
        <article id="main-col">
          <h1 class="page-title">Services</h1>
          <ul id="services">
            <li>
              <h3>Website Design</h3>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus mi augue, viverra sit amet ultricies at, vulputate id lorem. Nulla facilisi.</p>
						  <p>Pricing: $1,000 - $3,000</p>
            </li>
            <li>
              <h3>Website Maintenance</h3>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus mi augue, viverra sit amet ultricies at, vulputate id lorem. Nulla facilisi.</p>
						  <p>Pricing: $250 per month</p>
            </li>
            <li>
              <h3>Website Hosting</h3>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus mi augue, viverra sit amet ultricies at, vulputate id lorem. Nulla facilisi.</p>
						  <p>Pricing: $25 per month</p>
            </li>
          </ul>
        </article>
<?php

if(isset($_POST["form"])){
    $ad = $_POST["ad"];
    $mail = $_POST["mail"];
    $mesaj = $_POST["mesaj"];
    
    if(empty($ad)){
        $error = "Ad boşdur";
    }
    if(empty($mail)){
        $error = "Epoşt boşdur";
    }
    if(empty($mesaj)){
        $error = "Mesaj boşdur";
    }
    if(strlen($ad)>20 || strlen($ad)<3){
        $error="Ad min 3 max 20 olmalidi";
    }
    if(strlen($mesaj)>20 || strlen($mesaj)<3){
        $error="Ad min 3 max 20 olmalidi";
    }
    if(!isset($error)){
        echo "Təbriklər";
    }
    else {
        echo $error;
    }
}

?>
        <aside id="sidebar">
          <div class="dark">
            <h3>Get A Quote</h3>
            <form method="POST" action="" class="quote">
  						<div>
  							<label>Ad girin</label><br>
  							<input type="text" name="ad" placeholder="Name" value="<?php if (isset ($ad)){echo $ad;}?>">
  						</div>
  						<div>
  							<label>Email</label><br>
  							<input type="email" name="mail" placeholder="Email Address">
  						</div>
  						<div>
  							<label>Message</label><br>
  							<textarea name="mesaj" placeholder="Message"></textarea>
  						</div>
  						<button class="button_1" name="form" type="submit">Göndər</button>
					</form>
          </div>
        </aside>
      </div>
    </section>

    <footer>
      <p>Acme Web Deisgn, Copyright &copy; 2019</p>
    </footer>
  </body>
</html>
