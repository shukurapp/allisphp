<?php
require_once("head.php");
if (!isset ($_SESSION ["login"])){
    die ("Once bir giris edin");
}
/* User profile menu*/




$user = $db->cek("users where login='{$_SESSION ["login"]}'");



echo 'Salam hormetli '. $_SESSION ["login"].'<hr>';
echo "{$_SERVER ["HTTP_HOST"]}<hr>";

echo '<div><a href="logout.php">Saytı tərk et</a></div>';
//print_r ($user);
?>
