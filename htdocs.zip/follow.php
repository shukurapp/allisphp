<?php
include ("head.php");
switch ($_GET["act"]) {
    
default:
    echo "Dost listem";
    echo "<hr>";
    $dost=$db->cek ("users,5friends where users.login=5friends.dost1");
    $i=1;
    foreach ($dost as $list) {
     echo $i.$list["dost2"]."<br/>";
     $i++;
    }
    
    
    break;
    case "gonder":
$id=trim ($_GET ["id"]); //dost
$me=trim ($_SESSION ["login"]); //men


if ($id==$me) {
    die ("Sehv ozune dost yollaya bilmezsen.");
}
$add=$db->cek("`5friends` where dost1='$me' and dost2='$id' or dost1='$id' and dost2='$me'");
mysqli_free_result($add);
echo $add;
//print_r ($add);


//echo $add->num_rows;
break;
}
?>