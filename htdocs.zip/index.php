<?php
require_once("head.php");
if(isset($_POST["form"])){
$login = htmlspecialchars($_POST["login"]);
$pass = htmlspecialchars($_POST["pass"]);


$cek=$db->cek("users where `login`='$login' and `pass`='$pass'");
if ($cek->num_rows > 0){
    
    echo "Giris ugurludur";
    

    
    $_SESSION ["user"]=true;
    $_SESSION ["login"]=$login;
    $_SESSION ["pass"]=$pass;
    header ("refresh:2; url=profile.php");
    
}
else {
    echo "Sifre yalnisdi";
}
}

?>
<section id="boxes">
      <div class="container">
        <h3>Subscribe To Our Newsletter</h3>
<form class="quote" method="POST" action="<?php echo $_SERVER["PHP_SELF"];?>">
<div><label>UserName </label><br><input type="text" placeholder="Istifadeci adi girin" name="login" value="<?php if(isset($_SESSION ["login"])){echo $_SESSION["login"];}?>"></div><div><label>Password </label><br><input type="text" name="pass" placeholder="Parol girin" value="<?php if(isset($_SESSION ["pass"])){echo $_SESSION["pass"];}?>"></div> <button class="button_1" type="submit" name="form">DaxiL oL </button></form>
<br><a class="button_1" href="signup.php">Qeydiyyat</a>
</div></section>


<?php 
$all=$db->cek("`share`");

foreach($all as $file){


$say = $db->cek ("`comments` where `share_id`='{$file["id"]}'")->num_rows;
echo "<a href=\"cat.php?act=fayl&id={$file["id"]}\">{$file["title"]}</a> / Şərh: ({$say})<hr>";
    //print_r($file);
}





 ?>

        
