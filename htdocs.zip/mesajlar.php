<?php
require("config.php");


$sess=$_SESSION["login"];


$log=$db->cek ("users where login='{$sess}'")->fetch_assoc();
$id=$log["id"];


$mesaj_cek=$db->cek("mesaj where user_id='$id'");
foreach ($mesaj_cek as $all){
    echo $all ["mesaj"];
}


?>
