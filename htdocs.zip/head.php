<?php
require ("config.php");


$link = $_SERVER["SCRIPT_NAME"];
$self=$_SERVER["PHP_SELF"];
$vip=$_SERVER["REQUEST_URL"];
print_r ($vip);
?>
<!doctype html>
<html>
<head>
<title>Bas sehife </title>
<meta name="viewport" content="width=width-device, initial-scale=1">
<link rel="stylesheet" href="css/style.css">
</head>
<body>
    
    <header>
      <div class="container">
        <div id="branding">
          <h1><span class="highlight">Wap</span> Web Design</h1>
        </div>
        <nav>
          <ul>
              
            <li class="<?php if($self=="/index.php"){echo "current";}?>"><a href="/index.php">Ana səhifə</a></li>
            <li class="<?php if($self=="/about.php"){echo "current";}?>"><a href="/about.php">Haqqımızda</a></li>
            <li class="<?php if($self=="/services.php"){echo "current";}?>"><a href="/services.php">Wap xidmətləri</a></li>
          <?php if ($self=="/signup.php"){echo '<li class="current"><a href="/index.php">Giris</a></li>';} ?>
          <li class="<?php if ($self=="/cat.php"){echo"current";}?>"><a href="/cat.php">Kateqoriyalar</a></li>
          
          
          <?php if ($self!=="/index.php"){ echo "Geriye";} ?>
          </ul>
        </nav>
      </div>
    </header>
