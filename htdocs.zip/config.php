<?php 
session_start();
class DB {
    
  public $host="localhost";
  public $user="root";
  public $pass="";
  public $db="mydb";
  public $sql="";
  public  function __construct(){
        
        $this->sql=@mysqli_connect($this->host,$this->user,$this->pass,$this->db);
           
    

}
        
    function cek($query) {
        $pre=$this->sql->query("SELECT * FROM {$query}");
        
        if ($pre->num_rows>0) {
        
          return $pre;
        }
        else {
            return "Istifadeci tapilmadi";
        }
   
}





function exe($query) {
        $pre=$this->sql->query("SELECT * FROM {$query}");
        $arr=array();
        if ($pre->num_rows>0) {
        while ($row=$pre->fetch_assoc ()){
        $arr[]=$row;
        
    }
          return $arr;
        }
        else {
            echo "Istifadeci tapilmadi";
        }
   
}



function qeyd($val){
    $add=$this->sql->query("INSERT INTO $val");
}


function insert($insert,$log,$pass,$date) {
    $yoxla=$this->sql->query("SELECT * FROM {$insert} where `login`='$log'");
    if ($yoxla->num_rows>0) {
        echo "Bu user istifade olinur";
    }
    else {
    $insert=$this->sql->query("INSERT INTO $insert set `login`='$log',`pass`='$pass',`date`='$date'") or die (mysqli_error ($this->sql));
         echo "Qeydiyyat ugurla yekunlasdi";
$_SESSION ["user"]=true;
    $_SESSION ["login"]=$log;
    $_SESSION ["pass"]=$pass;
    header ("refresh:2; url=profile.php");
    }

}
}
$db = new DB();


?>
