<?php
require_once("head.php");
if (isset ($_SESSION["login"])){
    header ("refresh:5; url=profile.php");
    die ();
}
if(isset($_POST["form"])){
$login = htmlspecialchars($_POST["login"]);
$pass = htmlspecialchars($_POST["pass"]);
$date=date ("d/m/Y H:i:s");

$cek=$db->insert("users",$login,$pass,$date);

    
    
    
}

?>
<section id="boxes">
      <div class="container">
<form class="quote" method="POST" action="<?php echo $_SERVER["PHP_SELF"];?>"><label>UserName </label><br><input type="text" placeholder="Istifadeci adi girin" name="login"><br><label>Password </label><br><input type="text" name="pass" placeholder="Parol girin"><br> <button class="button_1" name="form">Qeyd oL </button></form>
<br><a class="button_1" href="index.php">Daxil ol</a>
</div></section>
