<?php
require ("head.php");
switch ($_GET ["act"]){
default:
$cek = $db->cek ("cat");
foreach($cek as $cat){
    echo "<a href='?act=cat&id=".$cat ["id"]."'>".$cat["name"]."</a><hr>";
}
echo "Kateqoriya sayi: ".$cek->num_rows;
break;
case "cat":
$cat_id=$_GET["id"]; //gelen cat_id
$cek = $db->cek("share where cat_id='$cat_id'");
foreach($cek as $fayl){

$cats=$db->cek ("cat where id='$cat_id'")->fetch_assoc ();
 echo "<a href='?act=cat&id=".$cats ["id"]."'>".$cats["name"]."</a><hr>";
    echo "<a href='?act=fayl&id=".$fayl ["id"]."'>".$fayl["title"]."</a><hr>";
}

break;

case "fayl":
$id=$_GET["id"]; //faylinidi

$sql=$db->cek ("share where id='$id'");


foreach($sql as $fayl){

$kim=$db->cek("users where id='{$fayl ["user_id"]}'")->fetch_assoc();


echo $fayl ["title"]."<hr>";
echo $fayl ["desc"]."<hr>";

echo "<a href='paylash.php?id=".$fayl ["id"]."'>Paylas </a>";
echo "<a href='users.php?id=".$kim ["id"]."'>". $kim["login"]." </a><br>";


$comm=$db->cek("`comments` where `share_id`='$id'");
foreach ($comm as $serh){


$user=$db->cek("users where id='{$serh ["user_id"]}'")->fetch_assoc();


    echo $serh ["mesaj"]."<br>{$serh ["date"]} {$user["login"]}";
}

if (isset($_POST["form"])){

if ($_SESSION["token"]!==$_POST["token"]){
    die ("Token invalid");
}
if (time()>=$_SESSION["time"]){
die("Vaxt bitdi");
}
$date = date("d/m/y H:i:s");
$mesaj=$_POST ["mesaj"];
    if (!empty ($_POST["mesaj"])){
        $sql=$db->qeyd("comments set share_id='$id',user_id='{$kim["id"]}',mesaj='$mesaj',date='$date'");
    }
    else {
        echo "xanalar bosdu...";
    }
    
    
    
    
}
$_SESSION["token"]=bin2hex(rand(2,10032));
$_SESSION ["time"]=time()+8;
echo '<aside id="sidebar">
          <div class="dark">
            <h3>Şərh göndər</h3>
            <form method="POST" action="" class="quote">
  						
 <div>
  							<label>Message</label><br>
  							<textarea cols="40" rows="4" name="mesaj" placeholder="Message"></textarea>
  						</div>
  						<div>
  						    <input type="hidden" name="token" value="'.$_SESSION["token"].'">
  						</div>
  						<button class="button_1" name="form" type="submit">[Göndər]</button>
					</form>
          </div>
        </aside>
  						</div>';




}

break;
}
?>
